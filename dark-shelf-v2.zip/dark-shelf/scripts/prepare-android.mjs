// Applies Dark Shelf's look and version to the Capacitor Android project that CI generates
// with `npx cap add android`. Pure Node, no dependencies.
//   APP_VERSION_CODE  positive integer (defaults to 1)
//   APP_VERSION_NAME  display version, e.g. "1.0.42" (defaults to "1.0")
import { cpSync, existsSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const resDir = "android/app/src/main/res";
const gradleFile = "android/app/build.gradle";

if (!existsSync(resDir) || !existsSync(gradleFile)) {
  console.error("Android project not found. Run `npx cap add android` first.");
  process.exit(1);
}

// Capacitor ships white splash PNGs in every drawable-* folder; drop them so our black splash.xml wins.
for (const dir of readdirSync(resDir)) {
  const splash = join(resDir, dir, "splash.png");
  if (dir.startsWith("drawable") && existsSync(splash)) rmSync(splash);
}

// Icons, black launch screen, black window/status/navigation bars.
cpSync("resources/android/res", resDir, { recursive: true });

const versionCode = Number.parseInt(process.env.APP_VERSION_CODE ?? "1", 10);
const versionName = process.env.APP_VERSION_NAME ?? "1.0";
if (!Number.isInteger(versionCode) || versionCode < 1 || versionCode > 2100000000) {
  console.error(`APP_VERSION_CODE must be a positive integer, got "${process.env.APP_VERSION_CODE}".`);
  process.exit(1);
}
if (!/^[0-9A-Za-z.+-]+$/.test(versionName)) {
  console.error(`APP_VERSION_NAME has unsupported characters: "${versionName}".`);
  process.exit(1);
}

const gradle = readFileSync(gradleFile, "utf8");
const updated = gradle
  .replace(/versionCode \d+/, `versionCode ${versionCode}`)
  .replace(/versionName "[^"]*"/, `versionName "${versionName}"`);
if (updated === gradle && !(gradle.includes(`versionCode ${versionCode}`) && gradle.includes(`versionName "${versionName}"`))) {
  console.error("Could not set versionCode/versionName in android/app/build.gradle.");
  process.exit(1);
}
writeFileSync(gradleFile, updated);

console.log(`Android project prepared: version ${versionName} (${versionCode}).`);
