import { useCallback, useEffect, useRef } from "react";

const HOLD_MS = 500;
const MOVE_TOLERANCE = 10;

/**
 * Tap vs. ~500ms hold on touch and mouse. Movement (scrolling) or a scroll event cancels both,
 * so swiping through the list never triggers an action.
 */
export function useLongPress(onTap: () => void, onLongPress: () => void) {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const fired = useRef(false);
  const cancelled = useRef(false);

  const clear = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  }, []);

  const cancel = useCallback(() => {
    cancelled.current = true;
    clear();
  }, [clear]);

  useEffect(() => {
    const onScroll = () => {
      if (start.current) cancel();
    };
    window.addEventListener("scroll", onScroll, { capture: true, passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll, { capture: true });
      clear();
    };
  }, [cancel, clear]);

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    start.current = { x: e.clientX, y: e.clientY };
    fired.current = false;
    cancelled.current = false;
    clear();
    timer.current = setTimeout(() => {
      fired.current = true;
      timer.current = null;
      if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate?.(12);
      onLongPress();
    }, HOLD_MS);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!start.current) return;
    const dx = Math.abs(e.clientX - start.current.x);
    const dy = Math.abs(e.clientY - start.current.y);
    if (dx > MOVE_TOLERANCE || dy > MOVE_TOLERANCE) cancel();
  };

  const onPointerUp = () => {
    const shouldTap = start.current && !fired.current && !cancelled.current;
    clear();
    start.current = null;
    if (shouldTap) onTap();
  };

  const onPointerLeave = () => {
    if (start.current && !fired.current) cancel();
    start.current = null;
  };

  return {
    onPointerDown,
    onPointerMove,
    onPointerUp,
    onPointerLeave,
    onPointerCancel: onPointerLeave,
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
    onKeyDown: (e: React.KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        onTap();
      } else if (e.key === "ContextMenu" || (e.shiftKey && e.key === "F10")) {
        e.preventDefault();
        onLongPress();
      }
    },
  };
}
