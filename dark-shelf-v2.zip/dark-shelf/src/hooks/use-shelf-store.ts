import { useCallback, useEffect, useRef, useState } from "react";

import { newId } from "@/lib/clipboard";
import type { ShelfItem, ShelfMode, ShelfView } from "@/lib/shelf";

const ITEMS_KEY = "darkshelf.items.v1";
const PREFS_KEY = "darkshelf.prefs.v1";

interface Prefs {
  mode: ShelfMode;
  view: ShelfView;
}

function seedItems(): ShelfItem[] {
  const now = Date.now();
  const base = { tag: "", color: "none" as const, pinned: false };
  return [
    {
      ...base,
      id: newId(),
      mode: "clipboard",
      title: "Email sign-off",
      content: "Thanks for your time,\nPriyam",
      color: "sage",
      pinned: true,
      tag: "work",
      createdAt: now,
      updatedAt: now,
    },
    {
      ...base,
      id: newId(),
      mode: "clipboard",
      title: "",
      content: "Running about 10 minutes late, see you soon.",
      tag: "personal",
      createdAt: now - 1000,
      updatedAt: now - 1000,
    },
    {
      ...base,
      id: newId(),
      mode: "clipboard",
      title: "Shipping address",
      content: "221B Baker Street, London NW1 6XE",
      color: "amber",
      tag: "personal",
      createdAt: now - 2000,
      updatedAt: now - 2000,
    },
    {
      ...base,
      id: newId(),
      mode: "bookmarks",
      title: "",
      content: "developer.mozilla.org/en-US/docs/Web",
      color: "slate",
      tag: "reference",
      createdAt: now,
      updatedAt: now,
    },
    {
      ...base,
      id: newId(),
      mode: "bookmarks",
      title: "Reading list",
      content: "https://news.ycombinator.com",
      tag: "read",
      createdAt: now - 1000,
      updatedAt: now - 1000,
    },
  ];
}

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

/** All Dark Shelf data lives in localStorage; nothing leaves the device. */
export function useShelfStore() {
  const [items, setItems] = useState<ShelfItem[]>([]);
  const [prefs, setPrefs] = useState<Prefs>({ mode: "clipboard", view: "list" });
  const [ready, setReady] = useState(false);
  const loaded = useRef(false);

  useEffect(() => {
    const stored = readJson<ShelfItem[]>(ITEMS_KEY);
    setItems(Array.isArray(stored) ? stored : seedItems());
    const storedPrefs = readJson<Partial<Prefs>>(PREFS_KEY);
    if (storedPrefs) setPrefs((p) => ({ ...p, ...storedPrefs }));
    loaded.current = true;
    setReady(true);
  }, []);

  useEffect(() => {
    if (!loaded.current) return;
    try {
      localStorage.setItem(ITEMS_KEY, JSON.stringify(items));
    } catch {
      // storage full or blocked; keep the in-memory copy
    }
  }, [items]);

  useEffect(() => {
    if (!loaded.current) return;
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    } catch {
      // ignore
    }
  }, [prefs]);

  const upsert = useCallback((item: ShelfItem) => {
    setItems((list) => {
      const exists = list.some((i) => i.id === item.id);
      return exists ? list.map((i) => (i.id === item.id ? item : i)) : [item, ...list];
    });
  }, []);

  const remove = useCallback((id: string) => {
    setItems((list) => list.filter((i) => i.id !== id));
  }, []);

  const togglePin = useCallback((id: string) => {
    setItems((list) =>
      list.map((i) => (i.id === id ? { ...i, pinned: !i.pinned, updatedAt: Date.now() } : i)),
    );
  }, []);

  const duplicate = useCallback((id: string) => {
    setItems((list) => {
      const src = list.find((i) => i.id === id);
      if (!src) return list;
      const now = Date.now();
      const copy: ShelfItem = {
        ...src,
        id: newId(),
        title: src.title.trim() ? `${src.title} copy` : "",
        pinned: false,
        createdAt: now,
        updatedAt: now,
      };
      return [copy, ...list];
    });
  }, []);

  return {
    ready,
    items,
    setItems,
    upsert,
    remove,
    togglePin,
    duplicate,
    mode: prefs.mode,
    view: prefs.view,
    setMode: (mode: ShelfMode) => setPrefs((p) => ({ ...p, mode })),
    setView: (view: ShelfView) => setPrefs((p) => ({ ...p, view })),
  };
}
