import { Copy, CopyPlus, Link2, Pencil, Pin, PinOff, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";

import { displayTitle, domainOf, type ShelfItem } from "@/lib/shelf";

import { BottomSheet, SheetAction } from "./primitives";

export function ItemActionsSheet({
  item,
  onClose,
  onEdit,
  onCopy,
  onTogglePin,
  onDuplicate,
  onDelete,
}: {
  item: ShelfItem | null;
  onClose: () => void;
  onEdit: (item: ShelfItem) => void;
  onCopy: (item: ShelfItem) => void;
  onTogglePin: (item: ShelfItem) => void;
  onDuplicate: (item: ShelfItem) => void;
  onDelete: (item: ShelfItem) => void;
}) {
  const [confirming, setConfirming] = useState(false);
  const [current, setCurrent] = useState<ShelfItem | null>(item);

  useEffect(() => {
    if (item) {
      setCurrent(item);
      setConfirming(false);
    }
  }, [item]);

  const shown = item ?? current;
  if (!shown) return null;
  const isBookmark = shown.mode === "bookmarks";
  const subtitle = isBookmark
    ? domainOf(shown.content) || shown.content
    : shown.tag
      ? `#${shown.tag}`
      : "Snippet";

  const run = (fn: (i: ShelfItem) => void) => () => {
    fn(shown);
    onClose();
  };

  return (
    <BottomSheet
      open={item !== null}
      onOpenChange={(open) => !open && onClose()}
      title={displayTitle(shown)}
      description={subtitle}
    >
      <SheetAction icon={<Pencil />} label="Edit" onClick={run(onEdit)} />
      <SheetAction
        icon={isBookmark ? <Link2 /> : <Copy />}
        label={isBookmark ? "Copy Link" : "Copy Text"}
        onClick={run(onCopy)}
      />
      <SheetAction
        icon={shown.pinned ? <PinOff /> : <Pin />}
        label={shown.pinned ? "Unpin" : "Pin"}
        onClick={run(onTogglePin)}
      />
      <SheetAction icon={<CopyPlus />} label="Duplicate" onClick={run(onDuplicate)} />
      <div className="mx-3 my-1 h-px bg-hairline" />
      <SheetAction
        icon={<Trash2 />}
        tone="danger"
        label={confirming ? "Confirm Delete?" : "Delete"}
        trailing={
          confirming ? <span className="text-xs text-muted-foreground">Tap again</span> : undefined
        }
        onClick={() => {
          if (!confirming) {
            setConfirming(true);
            return;
          }
          onDelete(shown);
          onClose();
        }}
      />
    </BottomSheet>
  );
}
