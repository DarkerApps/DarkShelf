import { useEffect, useState } from "react";

import { newId } from "@/lib/clipboard";
import {
  COLOR_LABELS,
  SHELF_COLORS,
  autoTitle,
  type ShelfColor,
  type ShelfItem,
  type ShelfMode,
} from "@/lib/shelf";
import { cn } from "@/lib/utils";

import { FieldLabel, Modal, PrimaryButton, colorBg, fieldClass } from "./primitives";

export type EditorState = { mode: ShelfMode; item: ShelfItem | null } | null;

export function ItemEditor({
  state,
  onClose,
  onSave,
  tags,
}: {
  state: EditorState;
  onClose: () => void;
  onSave: (item: ShelfItem) => void;
  tags: string[];
}) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tag, setTag] = useState("");
  const [color, setColor] = useState<ShelfColor>("none");
  const [mode, setMode] = useState<ShelfMode>("clipboard");

  useEffect(() => {
    if (!state) return;
    setMode(state.mode);
    setTitle(state.item?.title ?? "");
    setContent(state.item?.content ?? "");
    setTag(state.item?.tag ?? "");
    setColor(state.item?.color ?? "none");
  }, [state]);

  const isBookmark = mode === "bookmarks";
  const editing = Boolean(state?.item);
  const canSave = content.trim().length > 0;
  const suggestions = tags.filter((t) => t !== tag.trim()).slice(0, 8);

  const save = () => {
    if (!canSave) return;
    const now = Date.now();
    const base = state?.item;
    onSave({
      id: base?.id ?? newId(),
      mode,
      title: title.trim(),
      content: isBookmark ? content.trim() : content,
      tag: tag.trim().replace(/^#/, ""),
      color,
      pinned: base?.pinned ?? false,
      createdAt: base?.createdAt ?? now,
      updatedAt: now,
    });
    onClose();
  };

  return (
    <Modal
      open={state !== null}
      onOpenChange={(open) => !open && onClose()}
      title={`${editing ? "Edit" : "New"} ${isBookmark ? "bookmark" : "snippet"}`}
    >
      <form
        className="flex flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save();
        }}
      >
        <div>
          <FieldLabel htmlFor="ds-title">Heading</FieldLabel>
          <input
            id="ds-title"
            className={fieldClass}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={content.trim() ? autoTitle(mode, content) : "Optional, auto-generated"}
            maxLength={120}
            autoComplete="off"
          />
        </div>

        <div>
          <FieldLabel htmlFor="ds-content">{isBookmark ? "URL" : "Text"}</FieldLabel>
          {isBookmark ? (
            <input
              id="ds-content"
              className={fieldClass}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="example.com/page"
              inputMode="url"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              autoComplete="off"
            />
          ) : (
            <textarea
              id="ds-content"
              className={cn(fieldClass, "min-h-32 resize-y leading-relaxed")}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Text to copy with one tap"
              rows={5}
            />
          )}
        </div>

        <div>
          <FieldLabel htmlFor="ds-tag">Tag</FieldLabel>
          <input
            id="ds-tag"
            className={fieldClass}
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            placeholder="Optional"
            maxLength={32}
            autoCapitalize="none"
            autoComplete="off"
          />
          {suggestions.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {suggestions.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTag(t)}
                  className="rounded-full border border-hairline px-2.5 py-1 text-xs text-muted-foreground transition-colors active:bg-accent"
                >
                  #{t}
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <FieldLabel>Color</FieldLabel>
          <div className="flex items-center gap-3" role="radiogroup" aria-label="Color">
            {SHELF_COLORS.map((c) => {
              const active = c === color;
              return (
                <button
                  key={c}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={COLOR_LABELS[c]}
                  title={COLOR_LABELS[c]}
                  onClick={() => setColor(c)}
                  className={cn(
                    "grid size-10 place-items-center rounded-full border transition-colors",
                    active ? "border-foreground/60" : "border-hairline",
                  )}
                >
                  <span
                    className={cn(
                      "size-6 rounded-full",
                      c === "none" ? "border border-hairline bg-surface-raised" : colorBg[c],
                    )}
                  />
                </button>
              );
            })}
          </div>
        </div>

        <PrimaryButton type="submit" disabled={!canSave} className="mt-1 w-full">
          {editing ? "Save changes" : isBookmark ? "Save bookmark" : "Save snippet"}
        </PrimaryButton>
      </form>
    </Modal>
  );
}
