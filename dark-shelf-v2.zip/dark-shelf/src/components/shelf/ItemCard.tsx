import { Pin } from "lucide-react";

import { useLongPress } from "@/hooks/use-long-press";
import { displayTitle, type ShelfItem, type ShelfView } from "@/lib/shelf";
import { cn } from "@/lib/utils";

import { colorBg, colorBorder } from "./primitives";

export function ItemCard({
  item,
  view,
  onTap,
  onLongPress,
}: {
  item: ShelfItem;
  view: ShelfView;
  onTap: (item: ShelfItem) => void;
  onLongPress: (item: ShelfItem) => void;
}) {
  const handlers = useLongPress(
    () => onTap(item),
    () => onLongPress(item),
  );
  const title = displayTitle(item);
  const hint = item.mode === "bookmarks" ? "Tap to open, hold for options" : "Tap to copy, hold for options";

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${title}. ${hint}`}
      {...handlers}
      className={cn(
        "no-select group relative flex cursor-pointer touch-manipulation overflow-hidden rounded-2xl border bg-surface transition-[transform,background-color] duration-150 outline-none",
        "focus-visible:border-ring active:scale-[0.985] active:bg-surface-raised",
        colorBorder[item.color],
        view === "list" ? "min-h-14 items-center" : "min-h-[6.5rem] items-start",
      )}
    >
      {item.color !== "none" && (
        <span
          aria-hidden
          className={cn(
            "absolute top-0 bottom-0 left-0 w-[3px]",
            colorBg[item.color],
          )}
        />
      )}
      <div
        className={cn(
          "flex min-w-0 flex-1 gap-3",
          view === "list" ? "items-center px-4 py-3.5" : "h-full flex-col justify-between p-3.5",
        )}
      >
        <span
          className={cn(
            "min-w-0 text-[15px] leading-snug text-foreground",
            view === "list" ? "flex-1 truncate" : "line-clamp-3 break-words",
          )}
        >
          {title}
        </span>
        {item.pinned && (
          <Pin
            aria-label="Pinned"
            className={cn(
              "size-3.5 shrink-0 rotate-45 text-muted-foreground",
              view === "grid" && "self-end",
            )}
          />
        )}
      </div>
    </div>
  );
}
