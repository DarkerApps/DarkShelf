import { ClipboardCopy, Download, FileUp } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { copyText, newId } from "@/lib/clipboard";
import {
  backupFileName,
  buildBackup,
  mergeItems,
  parseBackup,
  type ShelfItem,
} from "@/lib/shelf";
import { cn } from "@/lib/utils";

import { GhostButton, Modal, PrimaryButton, Segmented, fieldClass } from "./primitives";

export function ExportDialog({
  open,
  onOpenChange,
  items,
  notify,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: ShelfItem[];
  notify: (text: string) => void;
}) {
  const [stamp, setStamp] = useState<Date | null>(null);
  useEffect(() => {
    if (open) setStamp(new Date());
  }, [open]);

  const json = useMemo(
    () => (stamp ? JSON.stringify(buildBackup(items, stamp), null, 2) : ""),
    [items, stamp],
  );

  const download = () => {
    if (!stamp) return;
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = backupFileName(stamp);
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    notify("Backup downloaded");
  };

  const copy = async () => {
    notify((await copyText(json)) ? "JSON copied" : "Copy failed");
  };

  const clips = items.filter((i) => i.mode === "clipboard").length;

  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title="Export backup"
      description={`${clips} snippets · ${items.length - clips} bookmarks`}
    >
      <div className="flex flex-col gap-3">
        <PrimaryButton onClick={download} className="w-full">
          <Download className="size-4" /> Download .json
        </PrimaryButton>
        <GhostButton onClick={copy} className="w-full">
          <ClipboardCopy /> Copy JSON
        </GhostButton>
        <p className="text-xs leading-relaxed text-muted-foreground">
          If the download doesn't start inside the Android app, use Copy JSON and paste it into a
          note or file.
        </p>
        <textarea
          readOnly
          value={json}
          aria-label="Backup JSON"
          className={cn(fieldClass, "h-40 resize-none font-mono text-[11px] leading-relaxed")}
        />
      </div>
    </Modal>
  );
}

export function ImportDialog({
  open,
  onOpenChange,
  items,
  onImport,
  notify,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: ShelfItem[];
  onImport: (next: ShelfItem[]) => void;
  notify: (text: string) => void;
}) {
  const [text, setText] = useState("");
  const [strategy, setStrategy] = useState<"merge" | "replace">("merge");
  const [error, setError] = useState<string | null>(null);
  const [confirmReplace, setConfirmReplace] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) {
      setText("");
      setError(null);
      setConfirmReplace(false);
      setFileName(null);
      setStrategy("merge");
    }
  }, [open]);

  useEffect(() => setConfirmReplace(false), [strategy, text]);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setFileName(file.name);
    setText(await file.text());
    setError(null);
  };

  const run = () => {
    const result = parseBackup(text, newId);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    if (strategy === "replace" && !confirmReplace) {
      setConfirmReplace(true);
      return;
    }
    onImport(strategy === "merge" ? mergeItems(items, result.items) : result.items);
    notify(`Imported ${result.items.length} item${result.items.length === 1 ? "" : "s"}`);
    onOpenChange(false);
  };

  return (
    <Modal open={open} onOpenChange={onOpenChange} title="Import backup" description="From a .json file or pasted JSON">
      <div className="flex flex-col gap-3">
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json,text/plain"
          className="hidden"
          onChange={(e) => void onFile(e.target.files?.[0])}
        />
        <GhostButton onClick={() => fileRef.current?.click()} className="w-full">
          <FileUp /> {fileName ?? "Choose .json file"}
        </GhostButton>
        <textarea
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            setError(null);
            setFileName(null);
          }}
          placeholder="…or paste backup JSON here"
          aria-label="Backup JSON"
          spellCheck={false}
          className={cn(fieldClass, "h-36 resize-none font-mono text-[11px] leading-relaxed")}
        />
        <Segmented
          size="sm"
          value={strategy}
          onChange={setStrategy}
          options={[
            { value: "merge", label: "Merge" },
            { value: "replace", label: "Replace" },
          ]}
        />
        <p className="text-xs leading-relaxed text-muted-foreground">
          {strategy === "merge"
            ? "Adds new items and keeps the newest copy of any item you already have."
            : "Deletes everything on this device and loads the backup instead."}
        </p>
        {error && <p className="text-xs text-coral">{error}</p>}
        <PrimaryButton
          onClick={run}
          disabled={!text.trim()}
          className={cn("w-full", confirmReplace && "bg-coral text-foreground")}
        >
          {confirmReplace ? "Confirm Replace?" : "Import"}
        </PrimaryButton>
      </div>
    </Modal>
  );
}

export function AboutDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Modal open={open} onOpenChange={onOpenChange} title="About">
      <div className="flex flex-col items-center gap-1 pt-2 pb-1 text-center">
        <img src="./icons/icon-192.png" alt="" className="mb-3 size-16 rounded-2xl border border-hairline" />
        <h2 className="text-lg font-medium text-foreground">Dark Shelf</h2>
        <p className="text-xs text-muted-foreground">Version 1.0</p>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          Everything stays on this device. No accounts, no servers, no analytics, no tracking.
        </p>
        <div className="my-4 h-px w-full bg-hairline" />
        <p className="text-xs text-muted-foreground">
          Developed by <span className="text-foreground">Priyam Rai</span>
        </p>
      </div>
    </Modal>
  );
}
