import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import {
  Download,
  Info,
  LayoutGrid,
  List,
  ListFilter,
  MoreVertical,
  Plus,
  Search,
  Upload,
  X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { useShelfStore } from "@/hooks/use-shelf-store";
import { copyText, openExternal } from "@/lib/clipboard";
import {
  normalizeUrl,
  tagsFor,
  visibleItems,
  type ShelfFilter,
  type ShelfItem,
} from "@/lib/shelf";
import { cn } from "@/lib/utils";

import { AboutDialog, ExportDialog, ImportDialog } from "./BackupDialogs";
import { FilterSheet } from "./FilterSheet";
import { ItemActionsSheet } from "./ItemActionsSheet";
import { ItemCard } from "./ItemCard";
import { ItemEditor, type EditorState } from "./ItemEditor";
import { Segmented } from "./primitives";

function ToolButton({
  label,
  active,
  onClick,
  children,
  dot,
}: {
  label: string;
  active?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
  dot?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "relative grid size-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground active:bg-accent [&_svg]:size-[18px]",
        active && "bg-surface text-foreground",
      )}
    >
      {children}
      {dot && <span className="absolute top-2 right-2 size-1.5 rounded-full bg-sage" />}
    </button>
  );
}

export function ShelfApp() {
  const store = useShelfStore();
  const { items, mode, view } = store;

  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<ShelfFilter>({ kind: "all" });
  const [filterOpen, setFilterOpen] = useState(false);
  const [actionItem, setActionItem] = useState<ShelfItem | null>(null);
  const [editor, setEditor] = useState<EditorState>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [notice, setNotice] = useState<{ text: string; key: number } | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = useCallback((text: string) => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    setNotice({ text, key: Date.now() });
    noticeTimer.current = setTimeout(() => setNotice(null), 1400);
  }, []);

  const tags = useMemo(() => tagsFor(items, mode), [items, mode]);
  const shown = useMemo(() => visibleItems(items, mode, filter, query), [items, mode, filter, query]);
  const counts = useMemo(
    () => ({
      clipboard: items.filter((i) => i.mode === "clipboard").length,
      bookmarks: items.filter((i) => i.mode === "bookmarks").length,
    }),
    [items],
  );

  // Reset a tag filter that no longer exists in this tab.
  useEffect(() => {
    if (filter.kind === "tag" && !tags.includes(filter.tag)) setFilter({ kind: "all" });
  }, [filter, tags]);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  const handleTap = useCallback(
    async (item: ShelfItem) => {
      if (item.mode === "bookmarks") {
        const url = normalizeUrl(item.content);
        if (url) openExternal(url);
        return;
      }
      notify((await copyText(item.content)) ? "Copied" : "Copy failed");
    },
    [notify],
  );

  const copyRaw = useCallback(
    async (item: ShelfItem) => {
      const text = item.mode === "bookmarks" ? normalizeUrl(item.content) : item.content;
      notify((await copyText(text)) ? (item.mode === "bookmarks" ? "Link copied" : "Copied") : "Copy failed");
    },
    [notify],
  );

  const isBookmarks = mode === "bookmarks";
  const filterLabel =
    filter.kind === "pinned" ? "Pinned" : filter.kind === "tag" ? `#${filter.tag}` : null;

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="sticky top-0 z-30 bg-background pt-safe">
        <div className="mx-auto max-w-3xl px-4">
          <Segmented
            value={mode}
            onChange={(m) => {
              store.setMode(m);
              setFilter({ kind: "all" });
            }}
            options={[
              {
                value: "clipboard",
                label: (
                  <>
                    Clipboard <span className="text-xs text-muted-foreground">{counts.clipboard}</span>
                  </>
                ),
              },
              {
                value: "bookmarks",
                label: (
                  <>
                    Bookmarks <span className="text-xs text-muted-foreground">{counts.bookmarks}</span>
                  </>
                ),
              },
            ]}
          />

          <div className="flex items-center gap-1 py-2">
            <ToolButton
              label="Search"
              active={searchOpen}
              onClick={() => {
                if (searchOpen) setQuery("");
                setSearchOpen((s) => !s);
              }}
            >
              <Search />
            </ToolButton>
            <ToolButton
              label="Filter"
              active={filterOpen}
              dot={filter.kind !== "all"}
              onClick={() => setFilterOpen(true)}
            >
              <ListFilter />
            </ToolButton>
            <ToolButton
              label={view === "list" ? "Switch to grid view" : "Switch to list view"}
              onClick={() => store.setView(view === "list" ? "grid" : "list")}
            >
              {view === "list" ? <LayoutGrid /> : <List />}
            </ToolButton>

            {filterLabel && (
              <button
                type="button"
                onClick={() => setFilter({ kind: "all" })}
                className="ml-1 inline-flex h-7 items-center gap-1 rounded-full border border-hairline bg-surface pr-2 pl-2.5 text-xs text-muted-foreground"
              >
                {filterLabel}
                <X className="size-3" />
              </button>
            )}

            <div className="ml-auto">
              <DropdownMenu.Root modal={false}>
                <DropdownMenu.Trigger asChild>
                  <button
                    type="button"
                    aria-label="More"
                    className="grid size-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground active:bg-accent data-[state=open]:bg-surface data-[state=open]:text-foreground"
                  >
                    <MoreVertical className="size-[18px]" />
                  </button>
                </DropdownMenu.Trigger>
                <DropdownMenu.Portal>
                  <DropdownMenu.Content
                    align="end"
                    sideOffset={6}
                    className="z-50 min-w-48 rounded-2xl border border-hairline bg-popover p-1.5 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95"
                  >
                    {[
                      { label: "Export Backup", icon: Download, onSelect: () => setExportOpen(true) },
                      { label: "Import Backup", icon: Upload, onSelect: () => setImportOpen(true) },
                      { label: "About", icon: Info, onSelect: () => setAboutOpen(true) },
                    ].map(({ label, icon: Icon, onSelect }) => (
                      <DropdownMenu.Item
                        key={label}
                        onSelect={onSelect}
                        className="flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-foreground outline-none data-[highlighted]:bg-accent"
                      >
                        <Icon className="size-4 text-muted-foreground" />
                        {label}
                      </DropdownMenu.Item>
                    ))}
                  </DropdownMenu.Content>
                </DropdownMenu.Portal>
              </DropdownMenu.Root>
            </div>
          </div>

          {searchOpen && (
            <div className="pb-3"><div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={searchRef}
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Escape") {
                    setQuery("");
                    setSearchOpen(false);
                  }
                }}
                placeholder={isBookmarks ? "Search titles, links, tags" : "Search titles, text, tags"}
                aria-label="Search"
                autoComplete="off"
                className="h-11 w-full rounded-xl border border-hairline bg-surface pr-10 pl-10 text-[15px] text-foreground outline-none placeholder:text-muted-foreground/70 focus:border-ring [&::-webkit-search-cancel-button]:hidden"
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setQuery("")}
                  className="absolute top-1/2 right-2 grid size-7 -translate-y-1/2 place-items-center rounded-full text-muted-foreground"
                >
                  <X className="size-4" />
                </button>
              )}
            </div></div>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-1 pb-32">
        {store.ready && shown.length === 0 ? (
          <div className="flex flex-col items-center px-6 pt-24 text-center">
            <p className="text-sm text-foreground">
              {query || filter.kind !== "all"
                ? "Nothing matches."
                : isBookmarks
                  ? "No bookmarks yet."
                  : "No snippets yet."}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {query || filter.kind !== "all"
                ? "Try another search or clear the filter."
                : `Tap + to save your first ${isBookmarks ? "link" : "snippet"}.`}
            </p>
          </div>
        ) : (
          <div
            className={cn(
              view === "list" ? "flex flex-col gap-2" : "grid grid-cols-2 gap-2 sm:grid-cols-3",
            )}
          >
            {shown.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                view={view}
                onTap={handleTap}
                onLongPress={setActionItem}
              />
            ))}
          </div>
        )}
      </main>

      <button
        type="button"
        aria-label={isBookmarks ? "Add bookmark" : "Add snippet"}
        onClick={() => setEditor({ mode, item: null })}
        className="fixed right-5 bottom-[max(env(safe-area-inset-bottom),1.25rem)] z-30 grid size-14 place-items-center rounded-full border border-hairline bg-surface-raised text-foreground transition-transform active:scale-95"
      >
        <Plus className="size-6" strokeWidth={1.75} />
      </button>

      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-[max(calc(env(safe-area-inset-bottom)+5.5rem),6.5rem)] z-40 flex justify-center"
      >
        {notice && (
          <div
            key={notice.key}
            className="inline-flex items-center gap-2 rounded-full border border-sage/30 bg-surface px-4 py-2 text-sm text-sage animate-in fade-in-0 slide-in-from-bottom-2"
          >
            <span className="size-1.5 rounded-full bg-sage" />
            {notice.text}
          </div>
        )}
      </div>

      <FilterSheet
        open={filterOpen}
        onOpenChange={setFilterOpen}
        filter={filter}
        onChange={setFilter}
        tags={tags}
      />
      <ItemActionsSheet
        item={actionItem}
        onClose={() => setActionItem(null)}
        onEdit={(item) => setTimeout(() => setEditor({ mode: item.mode, item }), 250)}
        onCopy={copyRaw}
        onTogglePin={(item) => store.togglePin(item.id)}
        onDuplicate={(item) => {
          store.duplicate(item.id);
          notify("Duplicated");
        }}
        onDelete={(item) => {
          store.remove(item.id);
          notify("Deleted");
        }}
      />
      <ItemEditor
        state={editor}
        onClose={() => setEditor(null)}
        onSave={store.upsert}
        tags={tags}
      />
      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} items={items} notify={notify} />
      <ImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        items={items}
        onImport={store.setItems}
        notify={notify}
      />
      <AboutDialog open={aboutOpen} onOpenChange={setAboutOpen} />
    </div>
  );
}
