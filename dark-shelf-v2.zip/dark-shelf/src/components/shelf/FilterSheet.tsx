import { Check, Hash, Layers, Pin } from "lucide-react";

import type { ShelfFilter } from "@/lib/shelf";

import { BottomSheet, SheetAction } from "./primitives";

function same(a: ShelfFilter, b: ShelfFilter) {
  if (a.kind !== b.kind) return false;
  return a.kind !== "tag" || (b.kind === "tag" && a.tag === b.tag);
}

export function FilterSheet({
  open,
  onOpenChange,
  filter,
  onChange,
  tags,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  filter: ShelfFilter;
  onChange: (filter: ShelfFilter) => void;
  tags: string[];
}) {
  const pick = (f: ShelfFilter) => {
    onChange(f);
    onOpenChange(false);
  };
  const tick = (f: ShelfFilter) =>
    same(filter, f) ? <Check className="size-4 text-foreground" /> : undefined;

  return (
    <BottomSheet open={open} onOpenChange={onOpenChange} title="Filter">
      <SheetAction icon={<Layers />} label="All" onClick={() => pick({ kind: "all" })} trailing={tick({ kind: "all" })} />
      <SheetAction icon={<Pin />} label="Pinned" onClick={() => pick({ kind: "pinned" })} trailing={tick({ kind: "pinned" })} />
      <div className="px-3 pt-4 pb-1 text-xs font-medium text-muted-foreground">Tags</div>
      {tags.length === 0 ? (
        <p className="px-3 pb-3 text-sm text-muted-foreground">
          No tags yet. Add one when editing an item.
        </p>
      ) : (
        tags.map((tag) => (
          <SheetAction
            key={tag}
            icon={<Hash />}
            label={tag}
            onClick={() => pick({ kind: "tag", tag })}
            trailing={tick({ kind: "tag", tag })}
          />
        ))
      )}
    </BottomSheet>
  );
}
