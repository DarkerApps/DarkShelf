import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { Drawer } from "vaul";

import { cn } from "@/lib/utils";
import type { ShelfColor } from "@/lib/shelf";

export const colorBg: Record<ShelfColor, string> = {
  none: "bg-transparent",
  sage: "bg-sage",
  amber: "bg-amber",
  slate: "bg-slate",
  coral: "bg-coral",
};

export const colorBorder: Record<ShelfColor, string> = {
  none: "border-hairline",
  sage: "border-sage/35",
  amber: "border-amber/35",
  slate: "border-slate/35",
  coral: "border-coral/35",
};

export function BottomSheet({
  open,
  onOpenChange,
  title,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={false}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-50 bg-scrim" />
        <Drawer.Content className="fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[85vh] max-w-xl flex-col rounded-t-3xl border border-b-0 border-hairline bg-surface pb-safe outline-none">
          <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-hairline" />
          <div className="px-5 pt-4 pb-2">
            <Drawer.Title className="truncate text-[15px] font-medium text-foreground">
              {title}
            </Drawer.Title>
            {description ? (
              <Drawer.Description className="mt-0.5 truncate text-xs text-muted-foreground">
                {description}
              </Drawer.Description>
            ) : (
              <Drawer.Description className="sr-only">{title}</Drawer.Description>
            )}
          </div>
          <div className="overflow-y-auto px-3 pb-2">{children}</div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

export function SheetAction({
  icon,
  label,
  onClick,
  tone = "default",
  trailing,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  tone?: "default" | "danger";
  trailing?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3.5 rounded-xl px-3 py-3 text-left text-[15px] transition-colors active:bg-accent",
        "[&_svg]:size-[18px] [&_svg]:shrink-0",
        tone === "danger" ? "text-coral" : "text-foreground [&_svg]:text-muted-foreground",
      )}
    >
      {icon}
      <span className="flex-1">{label}</span>
      {trailing}
    </button>
  );
}

export function Modal({
  open,
  onOpenChange,
  title,
  description,
  children,
  className,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-scrim data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:animate-out data-[state=closed]:fade-out-0" />
        <DialogPrimitive.Content
          className={cn(
            "fixed top-1/2 left-1/2 z-50 flex max-h-[90vh] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-3xl border border-hairline bg-surface outline-none",
            "data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95",
            className,
          )}
        >
          <div className="flex items-start justify-between gap-4 px-5 pt-5 pb-3">
            <div className="min-w-0">
              <DialogPrimitive.Title className="text-base font-medium text-foreground">
                {title}
              </DialogPrimitive.Title>
              <DialogPrimitive.Description
                className={description ? "mt-1 text-xs text-muted-foreground" : "sr-only"}
              >
                {description ?? title}
              </DialogPrimitive.Description>
            </div>
            <DialogPrimitive.Close
              aria-label="Close"
              className="-mt-1 -mr-1 grid size-9 shrink-0 place-items-center rounded-full text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:bg-accent active:bg-accent"
            >
              <X className="size-[18px]" />
            </DialogPrimitive.Close>
          </div>
          <div className="overflow-y-auto px-5 pb-5">{children}</div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export const fieldClass =
  "w-full rounded-xl border border-hairline bg-background px-3.5 py-3 text-[15px] text-foreground placeholder:text-muted-foreground/70 outline-none transition-colors focus:border-ring";

export function FieldLabel({ children, htmlFor }: { children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-xs font-medium text-muted-foreground">
      {children}
    </label>
  );
}

export function PrimaryButton({
  children,
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-foreground px-4 text-sm font-medium text-background transition-opacity active:opacity-80 disabled:opacity-35",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-hairline bg-surface-raised px-4 text-sm font-medium text-foreground transition-colors active:bg-accent disabled:opacity-35 [&_svg]:size-4 [&_svg]:text-muted-foreground",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
  size = "md",
}: {
  value: T;
  onChange: (value: T) => void;
  options: { value: T; label: ReactNode }[];
  className?: string;
  size?: "md" | "sm";
}) {
  return (
    <div
      role="tablist"
      className={cn(
        "grid gap-1 rounded-full border border-hairline bg-surface p-1",
        className,
      )}
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(opt.value)}
            className={cn(
              "flex items-center justify-center gap-2 rounded-full border font-medium transition-colors",
              size === "md" ? "h-10 text-sm" : "h-8 text-xs",
              active
                ? "border-hairline bg-surface-raised text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
