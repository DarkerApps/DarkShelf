import { createFileRoute } from "@tanstack/react-router";

import { ShelfApp } from "@/components/shelf/ShelfApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dark Shelf — Offline snippets & bookmarks" },
      {
        name: "description",
        content:
          "Save reusable text snippets and bookmarks on a pure-black screen. One tap to copy or open. Everything stays on your device.",
      },
      { property: "og:title", content: "Dark Shelf — Offline snippets & bookmarks" },
      {
        property: "og:description",
        content: "Minimal AMOLED shelf for text snippets and links. Offline, private, no accounts.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ShelfApp,
});
