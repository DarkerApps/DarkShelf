import { describe, expect, it } from "vitest";

import {
  autoTitle,
  backupFileName,
  mergeItems,
  normalizeUrl,
  parseBackup,
  visibleItems,
  type ShelfItem,
} from "./shelf";

const item = (over: Partial<ShelfItem>): ShelfItem => ({
  id: "x",
  mode: "clipboard",
  title: "",
  content: "hello",
  tag: "",
  color: "none",
  pinned: false,
  createdAt: 1,
  updatedAt: 1,
  ...over,
});

let n = 0;
const makeId = () => `gen-${++n}`;

describe("normalizeUrl", () => {
  it("prepends https:// to domain-only links", () => {
    expect(normalizeUrl("example.com/page")).toBe("https://example.com/page");
  });
  it("keeps existing http:// and https:// links unchanged", () => {
    expect(normalizeUrl("http://example.com")).toBe("http://example.com");
    expect(normalizeUrl("HTTPS://example.com")).toBe("HTTPS://example.com");
  });
});

describe("autoTitle", () => {
  it("uses the domain without www for blank bookmark titles", () => {
    expect(autoTitle("bookmarks", "https://www.github.com/foo/bar")).toBe("github.com");
  });
  it("uses the first line of a snippet, shortened", () => {
    expect(autoTitle("clipboard", "\nShort first line\nsecond")).toBe("Short first line");
    expect(autoTitle("clipboard", "a ".repeat(60)).endsWith("…")).toBe(true);
  });
});

describe("visibleItems", () => {
  const items = [
    item({ id: "1", title: "Alpha", content: "secret body", updatedAt: 3 }),
    item({ id: "2", title: "Beta", tag: "work", pinned: true, updatedAt: 1 }),
    item({ id: "3", mode: "bookmarks", content: "example.com" }),
  ];
  it("searches hidden content, not only headings", () => {
    expect(visibleItems(items, "clipboard", { kind: "all" }, "secret").map((i) => i.id)).toEqual(["1"]);
  });
  it("puts pinned items first", () => {
    expect(visibleItems(items, "clipboard", { kind: "all" }, "").map((i) => i.id)).toEqual(["2", "1"]);
  });
  it("filters by tag and keeps tabs separate", () => {
    expect(visibleItems(items, "clipboard", { kind: "tag", tag: "work" }, "").map((i) => i.id)).toEqual(["2"]);
    expect(visibleItems(items, "bookmarks", { kind: "all" }, "").map((i) => i.id)).toEqual(["3"]);
  });
});

describe("backup", () => {
  it("names the export file with a timestamp", () => {
    expect(backupFileName(new Date(2026, 10, 23, 9, 5, 7))).toBe(
      "dark-shelf-backup-2026-11-23-090507.json",
    );
  });
  it("rejects invalid JSON and items without a valid mode", () => {
    expect(parseBackup("{nope", makeId).ok).toBe(false);
    expect(parseBackup(JSON.stringify({ items: [{ mode: "notes", content: "x" }] }), makeId).ok).toBe(false);
  });
  it("merge keeps the most recently edited copy and adds new items", () => {
    const current = [item({ id: "a", content: "old", updatedAt: 5 }), item({ id: "b", updatedAt: 1 })];
    const incoming = [item({ id: "a", content: "new", updatedAt: 9 }), item({ id: "c" })];
    const merged = mergeItems(current, incoming);
    expect(merged.map((i) => i.id).sort()).toEqual(["a", "b", "c"]);
    expect(merged.find((i) => i.id === "a")?.content).toBe("new");
  });
});
