// Pure data rules for Dark Shelf: no React, no browser globals, so they are unit-testable.

export type ShelfMode = "clipboard" | "bookmarks";
export type ShelfColor = "none" | "sage" | "amber" | "slate" | "coral";
export type ShelfView = "list" | "grid";

export interface ShelfItem {
  id: string;
  mode: ShelfMode;
  title: string;
  content: string;
  tag: string;
  color: ShelfColor;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export type ShelfFilter = { kind: "all" } | { kind: "pinned" } | { kind: "tag"; tag: string };

export const SHELF_COLORS: readonly ShelfColor[] = ["none", "sage", "amber", "slate", "coral"];

export const COLOR_LABELS: Record<ShelfColor, string> = {
  none: "Neutral",
  sage: "Muted Sage",
  amber: "Muted Amber",
  slate: "Muted Slate",
  coral: "Dusty Coral",
};

export const BACKUP_APP_ID = "dark-shelf";
export const BACKUP_VERSION = 1;

/** Prepend https:// unless the URL already starts with http:// or https://. */
export function normalizeUrl(raw: string): string {
  const url = raw.trim();
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  return `https://${url.replace(/^\/+/, "")}`;
}

/** Hostname without "www." for a saved URL, or "" when it can't be parsed. */
export function domainOf(raw: string): string {
  const normalized = normalizeUrl(raw);
  if (!normalized) return "";
  try {
    return new URL(normalized).hostname.replace(/^www\./i, "");
  } catch {
    return "";
  }
}

const MAX_TITLE = 48;

function clip(text: string, max = MAX_TITLE): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.5 ? cut.slice(0, lastSpace) : cut).trimEnd()}…`;
}

/** Short heading for an item whose title was left blank. */
export function autoTitle(mode: ShelfMode, content: string): string {
  const text = content.trim();
  if (!text) return mode === "bookmarks" ? "Untitled link" : "Untitled snippet";
  if (mode === "bookmarks") {
    const domain = domainOf(text);
    return domain || clip(text);
  }
  const firstLine = text.split(/\r?\n/).find((line) => line.trim()) ?? text;
  return clip(firstLine.replace(/\s+/g, " ").trim());
}

export function displayTitle(item: Pick<ShelfItem, "title" | "mode" | "content">): string {
  return item.title.trim() || autoTitle(item.mode, item.content);
}

export function sortItems(items: ShelfItem[]): ShelfItem[] {
  return [...items].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return b.updatedAt - a.updatedAt;
  });
}

export function tagsFor(items: ShelfItem[], mode: ShelfMode): string[] {
  const set = new Set<string>();
  for (const item of items) {
    if (item.mode === mode && item.tag.trim()) set.add(item.tag.trim());
  }
  return [...set].sort((a, b) => a.localeCompare(b));
}

/** Items for one tab, narrowed by the filter and a search over title, hidden content and tag. */
export function visibleItems(
  items: ShelfItem[],
  mode: ShelfMode,
  filter: ShelfFilter,
  query: string,
): ShelfItem[] {
  const q = query.trim().toLowerCase();
  return sortItems(
    items.filter((item) => {
      if (item.mode !== mode) return false;
      if (filter.kind === "pinned" && !item.pinned) return false;
      if (filter.kind === "tag" && item.tag.trim().toLowerCase() !== filter.tag.toLowerCase())
        return false;
      if (!q) return true;
      return [displayTitle(item), item.content, item.tag].some((field) =>
        field.toLowerCase().includes(q),
      );
    }),
  );
}

// ---------- Backup ----------

export interface ShelfBackup {
  app: typeof BACKUP_APP_ID;
  version: number;
  exportedAt: string;
  items: ShelfItem[];
}

export function buildBackup(items: ShelfItem[], now: Date): ShelfBackup {
  return { app: BACKUP_APP_ID, version: BACKUP_VERSION, exportedAt: now.toISOString(), items };
}

/** dark-shelf-backup-YYYY-MM-DD-HHmmss.json in local time. */
export function backupFileName(now: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `dark-shelf-backup-${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}-${p(
    now.getHours(),
  )}${p(now.getMinutes())}${p(now.getSeconds())}.json`;
}

export type ParseResult = { ok: true; items: ShelfItem[] } | { ok: false; error: string };

function sanitizeItem(raw: unknown, index: number, makeId: () => string): ShelfItem | string {
  if (!raw || typeof raw !== "object") return `Item ${index + 1} is not an object.`;
  const r = raw as Record<string, unknown>;
  const mode = r["mode"];
  if (mode !== "clipboard" && mode !== "bookmarks")
    return `Item ${index + 1} needs mode "clipboard" or "bookmarks".`;
  const content = typeof r["content"] === "string" ? r["content"] : "";
  const title = typeof r["title"] === "string" ? r["title"] : "";
  if (!content.trim() && !title.trim()) return `Item ${index + 1} has no title or content.`;
  const color = SHELF_COLORS.includes(r["color"] as ShelfColor) ? (r["color"] as ShelfColor) : "none";
  const now = Date.now();
  const createdAt = typeof r["createdAt"] === "number" ? r["createdAt"] : now;
  return {
    id: typeof r["id"] === "string" && r["id"] ? r["id"] : makeId(),
    mode,
    title,
    content,
    tag: typeof r["tag"] === "string" ? r["tag"].trim() : "",
    color,
    pinned: r["pinned"] === true,
    createdAt,
    updatedAt: typeof r["updatedAt"] === "number" ? r["updatedAt"] : createdAt,
  };
}

/** Validate pasted or uploaded backup JSON. Accepts a Dark Shelf backup object or a bare item array. */
export function parseBackup(text: string, makeId: () => string): ParseResult {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { ok: false, error: "This isn't valid JSON." };
  }
  let list: unknown;
  if (Array.isArray(data)) list = data;
  else if (data && typeof data === "object" && Array.isArray((data as Record<string, unknown>)["items"]))
    list = (data as Record<string, unknown>)["items"];
  else return { ok: false, error: "No items found. Expected a Dark Shelf backup." };

  const items: ShelfItem[] = [];
  for (const [i, raw] of (list as unknown[]).entries()) {
    const result = sanitizeItem(raw, i, makeId);
    if (typeof result === "string") return { ok: false, error: result };
    items.push(result);
  }
  return { ok: true, items };
}

/** Merge: items with the same id keep whichever copy was edited most recently; new ids are added. */
export function mergeItems(current: ShelfItem[], incoming: ShelfItem[]): ShelfItem[] {
  const byId = new Map(current.map((item) => [item.id, item]));
  for (const item of incoming) {
    const existing = byId.get(item.id);
    if (!existing || item.updatedAt > existing.updatedAt) byId.set(item.id, item);
  }
  return [...byId.values()];
}
