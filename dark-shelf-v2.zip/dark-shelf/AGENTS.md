<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- All user data lives in browser localStorage via `src/hooks/use-shelf-store.ts`; no backend, accounts, analytics or network calls — the app must work fully offline and inside an Android WebView/APK.
- Pure data rules (URL normalizing, auto titles, search/filter, backup parse/merge) live in `src/lib/shelf.ts` and are covered by `src/lib/shelf.test.ts`; keep UI components free of that logic.
- Fonts are bundled from `@fontsource-variable/*` packages, never remote URLs, so text renders identically offline.
- Public asset references (manifest, icons) use relative `./` paths for static/APK packaging.
- Clipboard writes go through `copyText` in `src/lib/clipboard.ts` (textarea + execCommand fallback for Android WebView).
- The Android APK is built only in CI (`.github/workflows/android-apk.yml`): `vite.static.config.ts` prerenders to `dist/client`, Capacitor (`capacitor.config.json`) wraps it, and `scripts/prepare-android.mjs` overlays `resources/android/res` and the version; `android/` is generated per run and git-ignored, so native tweaks belong in those files, not a committed `android/` folder. Keep `vite.config.ts` free of static-build options so Lovable hosting is unaffected, and list every new route in `vite.static.config.ts` `pages`.
