// Static (plain files) build used to package the Android APK — see .github/workflows/android-apk.yml.
// Run with `npm run build:static`; output lands in dist/client (index.html + assets).
// The normal `vite.config.ts` stays untouched so Lovable hosting keeps working as before.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  // No server runtime: the APK serves files straight from inside the app.
  nitro: false,
  tanstackStart: {
    server: { entry: "server" },
    // Render "/" to dist/client/index.html at build time. Add new routes here when they are created.
    pages: [{ path: "/" }],
    prerender: { enabled: true, autoStaticPathsDiscovery: false },
  },
});
