# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Android APK

GitHub Actions builds an offline Android APK on every push to `main`, on `v*` tags, or on demand
(Actions tab → **Android APK** → **Run workflow**). Download it from the run's **Artifacts**; tagged
builds also attach it to a GitHub Release.

Without signing secrets the workflow builds a debug APK. Each debug build has a different key, so
Android only installs it after uninstalling the old one, which erases saved snippets (export a
backup first). For installable updates, create a keystore once and add it as repository secrets:

```sh
keytool -genkeypair -v -keystore dark-shelf.jks -alias darkshelf -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 dark-shelf.jks   # value for ANDROID_KEYSTORE_BASE64
```

Secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (e.g. `darkshelf`),
and optionally `ANDROID_KEY_PASSWORD`. Keep the `.jks` file safe — losing it means future builds can't
update the installed app.

Local static build: `npm run build:static` (output in `dist/client`).
